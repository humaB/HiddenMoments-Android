# No custom shrinking rules are required for the current WebView-only app.
